$(document).ready(function() {
	console.log("Welcome");
});